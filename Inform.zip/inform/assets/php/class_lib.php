<?php
//import classes here for use by files in the home directory
include('./assets/php/classes/user.php');
include('./assets/php/classes/post.php');
include('./assets/php/classes/community.php');
?>
<div id='pop-up-card-panel' class="uninterupted-max-height hide uninterupted-max-width fixed top-0 left-0 z-20">
    <div class='uninterupted-max-height uninterupted-max-width black-bg width unselected fixed z-n10' onclick='toggleThis("pop-up-card-panel");'></div>
    <div class='card max-width large-height vertical-margin-50 center white-bg'>
        <div class="float-right minute-size danger-txt margin-15 minute-line-height" onclick='toggleThis("pop-up-card-panel");'>&#10006;</div>
        <div id="pop-up-details-panel" class=' padding-20 vertical-padding-50'></div>
    </div>
    
</div>
<?php
//import classes here for use by files in the assets > php directory
include('classes/user.php');
include('classes/post.php');
include('classes/community.php');
?>